package com.nitesh.highframeplayer;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.ui.PlayerView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_VIDEO = 1001;

    private PlayerView playerView;
    private ExoPlayer player;
    private TextView status;
    private float sourceFrameRate = C.RATE_UNSET;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerView = findViewById(R.id.player_view);
        status = findViewById(R.id.status);
        Button open = findViewById(R.id.open_button);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        open.setOnClickListener(v -> pickVideo());

        player.addAnalyticsListener(new AnalyticsListener() {
            @Override
            public void onVideoInputFormatChanged(EventTime eventTime, Format format) {
                sourceFrameRate = format.frameRate;
                updateSurfaceFrameRate();
                updateStatus(format);
            }
        });

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_READY) {
                    updateSurfaceFrameRate();
                }
            }
        });

        status.setText("High Frame Player\nOpen a video");
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}

            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        }
    }

    private void updateSurfaceFrameRate() {
        if (sourceFrameRate <= 0 || playerView.getVideoSurfaceView() == null) return;

        View surfaceView = playerView.getVideoSurfaceView();
        if (!(surfaceView instanceof SurfaceView)) return;

        Surface surface = ((SurfaceView) surfaceView).getHolder().getSurface();
        if (surface == null || !surface.isValid()) return;

        if (Build.VERSION.SDK_INT >= 31) {
            surface.setFrameRate(
                    sourceFrameRate,
                    Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                    Surface.CHANGE_FRAME_RATE_ALWAYS);
        } else if (Build.VERSION.SDK_INT >= 30) {
            surface.setFrameRate(
                    sourceFrameRate,
                    Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
        }
    }

    private void updateStatus(Format format) {
        String fps = format.frameRate > 0
                ? String.format(Locale.US, "%.2f FPS", format.frameRate)
                : "FPS unknown";
        String codec = format.sampleMimeType != null ? format.sampleMimeType : "codec unknown";
        status.setText("Source: " + fps + "\n" + codec + "\nRefresh matching: ON");
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}