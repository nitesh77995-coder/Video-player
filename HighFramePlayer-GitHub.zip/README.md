# High Frame Player

A simple Android video player built with AndroidX Media3/ExoPlayer.

## Features
- Local video picker
- Hardware-accelerated Media3 playback
- Automatic source FPS detection
- Android display refresh-rate matching
- Full-screen landscape player
- Playback controls and seeking
- H.264/H.265/VP9/AV1 support when supported by the device decoder

## Important
This first version does **not** create new frames. A 30 FPS video remains 30 FPS. The app asks Android to match the display refresh rate to the source video where supported.

True 30→60/120 FPS motion interpolation is a separate, much heavier feature and can be added later.

## Build
The GitHub Actions workflow builds:
`app/build/outputs/apk/debug/app-debug.apk`